package es.ucm.fdi.ici.c1920.practica0.grupoYY.MsPacManController;

import java.util.ArrayList;
import java.util.Random;

import es.ucm.fdi.ici.c1920.practica0.grupoYY.GhostsController.Ghosts;
import es.ucm.fdi.ici.c1920.practica0.grupoYY.GhostsController.Ghosts.Pair;
import pacman.controllers.PacmanController;
import pacman.game.Constants;
import pacman.game.Constants.DM;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;
import pacman.game.Game;

public class MsPacMan extends PacmanController {
	

	@Override
	public MOVE getMove(Game game, long timeDue) {
		/* 1. Tengo la Power Pill o no tengo la Power Pill  */
		
		if(ghostsEdible(game).size() != 0) {
			return pacmanHasPowerPill(game);
			
		}
		
		else { // No tengo la Power Pill
			return pacmanNotHasPowerPill(game); 
		}
		
	}
	
	/** 
	 * Controla todas las acciones si Pac Man tiene la PowerPill.
	 * @param game
	 * @return movimiento a hacer. 
	 */
	private MOVE pacmanHasPowerPill(Game game) {
		if(isPowerPillNearToFinish(game)) {
			return pacmanNotHasPowerPill(game);
		}
		else {
			if(isGhostReachable(game)) {
				return chaseGhost(game); 
			}
			else {
				return eatPillsAvoidingGhosts(game);  
			}
		}
	}
	/** 
	 * Devuelve el movimiento siguiente para alcanzar al fantasma mas cercano desde PacMan. 
	 * @param game: game
	 * @return movimiento para alcanzar al fantasma mas cercano. 
	 */
	private MOVE chaseGhost(Game game) {
		Ghosts.Pair g = new Ghosts.Pair(-1, 0);
		double min = Double.POSITIVE_INFINITY;
		for(GHOST ghostType : GHOST.values()) {
			double dist = game.getDistance(game.getGhostCurrentNodeIndex(ghostType), game.getPacmanCurrentNodeIndex(), DM.PATH);
			if(dist < min) {
				min = dist;
				g.setIndex1(game.getGhostCurrentNodeIndex(ghostType));
			}
		}
		g.setIndex2(min);
		return game.getApproximateNextMoveTowardsTarget( game.getPacmanCurrentNodeIndex(), g.getIndex1() ,game.getPacmanLastMoveMade(), DM.PATH); 
	}
	/** 
	 * Comprueba si hay alg�n fantasma que pueda ser alcanzado por PacMan. 
	 * @param game
	 * @return true: Si hay algun fantasma alcanzable por PacMan. 
	 */
	private boolean isGhostReachable(Game game) {
		ArrayList<GHOST> edibleGhosts = ghostsEdible(game); 
		GHOST focusGhost = null; 
		if(edibleGhosts.size() <= 0) { // no hay fantasmas comibles
			return false; 
		}
		focusGhost = nearestGhost(game, edibleGhosts); 
		//focusGhost = Ghosts.findNearestGhostToPill(game, game.getPacmanCurrentNodeIndex());
		
		int nodeFocusGhost = game.getGhostCurrentNodeIndex(focusGhost); 
		int pacmanNode = game.getPacmanCurrentNodeIndex(); 
		double distancePacmanFocusGhost = game.getDistance(pacmanNode, nodeFocusGhost, DM.EUCLID);
		int ghostEdibleTime = game.getGhostEdibleTime(focusGhost); 
		double ratioGhost = ghostEdibleTime / Constants.GHOST_SPEED_REDUCTION; 
		if(ratioGhost + distancePacmanFocusGhost < ghostEdibleTime) { // el fantasma es alcanzable.
			return true; 
		}
		else {
			return false; 
		}
		
	}
	
	/** 
	 * Trata todas las acciones si PacMan no posee la power pill. 
	 * @param game
	 * @return movimiento pensado analizado por la logica de no tener la power pill. 
	 */
	private MOVE pacmanNotHasPowerPill(Game game) {
		Ghosts.Pair p = Ghosts.DistMsPacManNearPill(game);
		Ghosts.Pair g = Ghosts.findNearestGhostToPill(game, p.getIndex1());
		return  g.getIndex2() + p.getIndex2() < 80 && p.getIndex2() < g.getIndex2()+5 ? 
													game.getApproximateNextMoveTowardsTarget(game.getPacmanCurrentNodeIndex(),p.getIndex1(), game.getPacmanLastMoveMade() , DM.PATH) 
													: eatPillsAvoidingGhosts(game);
	}
	
	/** 
	 * Indica si PacMan va a dejar de tener alg�n fantasma comible. 
	 * @param game
	 * @return true: Si PacMan va a poder dejar de comer fantasmas en menos o en 10 segundos (limit). false: cualquier otro caso. 
	 */
	private boolean isPowerPillNearToFinish(Game game) {
		int limit = 10;
		int timeBlinky = game.getGhostEdibleTime(GHOST.BLINKY); 
		int timeInky = game.getGhostEdibleTime(GHOST.INKY); 
		int timePinky = game.getGhostEdibleTime(GHOST.PINKY); 
		int timeSue = game.getGhostEdibleTime(GHOST.SUE); 
		if(timeBlinky > limit || timeInky > limit || timePinky > limit || timeSue > limit) {
			return false; 
		}
		else {
			return true; 
		}
	}
	
	/** 
	 * Devuelve un movimiento para que PacMan alcance la pill mas cercana cambiando de recorrido si hay alg�n fantasma en el camino.
	 * @param game
	 * @return siguiente movimiento para llegar a la pill evitando fantasmas. 
	 */
	private MOVE eatPillsAvoidingGhosts(Game game) {
		int pacmanNode = game.getPacmanCurrentNodeIndex(); 
		Ghosts.Pair nPill = findPill(game, pacmanNode);
		if(nPill.getIndex2() == -1) { // si el fantasma esta hacia la pill. 
			return game.getApproximateNextMoveAwayFromTarget(pacmanNode, nPill.getIndex1(),game.getPacmanLastMoveMade(), DM.PATH); 
		}
		else { // el fantasma no cubre la pill.
			return game.getApproximateNextMoveTowardsTarget(pacmanNode, nPill.getIndex1(),game.getPacmanLastMoveMade(),  DM.PATH); 
		}
		
	}
	/** 
	 * Devuelve el tipo de fantasma mas cerca de PacMan.
	 * @param game
	 * @param ghosts: ArrayList que contiene los tipos de fantasmas que se comprueban. 
	 * @return el tipo de fantasma mas cercano de PacMan.
	 */
	private GHOST nearestGhost(Game game, ArrayList<GHOST> ghosts) {
		double distanciaMinima = Double.POSITIVE_INFINITY; 
		double distancia = -1; 
		int ghostNode = -1; 
		GHOST nearestGhost = null; 
		int pacmanNode = game.getPacmanCurrentNodeIndex();
		for(GHOST ghostType : GHOST.values()) {
			distancia = game.getDistance(pacmanNode,game.getGhostCurrentNodeIndex(ghostType), DM.PATH); 
			if(distancia < distanciaMinima && distancia!=-1) {
				distanciaMinima = distancia; 
				nearestGhost = ghostType;
			}
		}
		return nearestGhost; 
	}
	/** 
	 * Devuelve los fantasmas que son comibles en ese momento para PacMan. 
	 * @param game
	 * @return un ArrayList con los tipos de fantasmas comibles por PacMan. 
	 */
	private ArrayList<GHOST> ghostsEdible(Game game) {
		ArrayList<GHOST> edibleGhosts = new ArrayList<>();
		for(GHOST ghostType : GHOST.values()) {
			if(game.isGhostEdible(ghostType))
				edibleGhosts.add(ghostType);
		}
		return edibleGhosts;
	}
	
	private Ghosts.Pair findPill(Game game, int actNode){
		Ghosts.Pair p = new Ghosts.Pair(0,0);
		double min = Double.POSITIVE_INFINITY;
		for(int pill : game.getActivePillsIndices()) {
			double dist = game.getDistance(actNode, pill, DM.PATH);
			if(dist < min) {
				min = dist;
				p.setIndex1(pill);
			}
		}
		p.setIndex2(min);
		Ghosts.Pair g = Ghosts.findNearestGhostToPill(game, p.getIndex1());
		Ghosts.Pair sol = new Ghosts.Pair(0,0);
		if(p.getIndex2() < g.getIndex2() && p.getIndex2() + g.getIndex2() >= 20) {
			sol.setIndex1(p.getIndex1());
			sol.setIndex2(0);
		}
		else {
			sol.setIndex1(g.getIndex1());
			sol.setIndex2(-1);
		}
		return sol;
	}
}
