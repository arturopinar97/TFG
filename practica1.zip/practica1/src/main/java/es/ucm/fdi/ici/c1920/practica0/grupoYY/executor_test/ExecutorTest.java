package es.ucm.fdi.ici.c1920.practica0.grupoYY.executor_test;

import es.ucm.fdi.ici.c1920.practica0.grupoYY.GhostsController.Ghosts;
import es.ucm.fdi.ici.c1920.practica0.grupoYY.GhostsController.GhostsRandom;
import es.ucm.fdi.ici.c1920.practica0.grupoYY.MsPacManController.MsPacMan;
import es.ucm.fdi.ici.c1920.practica0.grupoYY.MsPacManController.PacManRandom;
import pacman.Executor;
import pacman.controllers.GhostController;
import pacman.controllers.PacmanController;
import pacman.game.internal.POType;

public class ExecutorTest {

	public static void main(String[] args) {
		Executor executor = new Executor.Builder()
				.setTickLimit(4000)
				.setVisual(true)
				.setScaleFactor(2.0)
				.build(); 
		PacmanController pacMan = new MsPacMan(); 
		GhostController ghosts = new Ghosts(); 
		
		System.out.println(
				executor.runGame(pacMan, ghosts, 50)
		);
	}
}
