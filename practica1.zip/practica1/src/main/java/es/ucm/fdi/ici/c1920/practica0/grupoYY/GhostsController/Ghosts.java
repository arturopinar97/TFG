package es.ucm.fdi.ici.c1920.practica0.grupoYY.GhostsController;

import java.util.EnumMap;
import java.util.Random;

import pacman.controllers.GhostController;
import pacman.game.Game;
import sun.security.ssl.Debug;
import pacman.game.Constants.DM;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;

public class Ghosts extends GhostController {
	private EnumMap<GHOST, MOVE> moves = new EnumMap<GHOST, MOVE>(GHOST.class);
	private MOVE[] allMoves = MOVE.values();
	private Random rnd = new Random();
	@Override

	public EnumMap<GHOST, MOVE> getMove(Game game, long timeDue) {
		moves.clear();
		Ghosts.Pair indiYdistPAC=DistMsPacManNearPill(game);
		Ghosts.Pair nearG = findNearestGhostToPill(game, indiYdistPAC.getIndex1());
		for (GHOST ghostType : GHOST.values()) {
			if (game.doesGhostRequireAction(ghostType)) {
				if(game.isGhostEdible(ghostType) || (nearG.getIndex2()>indiYdistPAC.getIndex2() && indiYdistPAC.getIndex2()<40)) {	
					moves.put(ghostType, game.getApproximateNextMoveAwayFromTarget(game.getGhostCurrentNodeIndex(ghostType),
							game.getPacmanCurrentNodeIndex(), game.getGhostLastMoveMade(ghostType), DM.PATH));
					
				}			
				else if(nearG.getIndex1() == game.getGhostCurrentNodeIndex(ghostType) && (indiYdistPAC.getIndex1()!=-1) ){
					moves.put(ghostType, game.getApproximateNextMoveTowardsTarget(game.getGhostCurrentNodeIndex(ghostType),
							indiYdistPAC.getIndex1(), game.getGhostLastMoveMade(ghostType), DM.PATH));
				
				}
				else
				{
					moves.put(ghostType, game.getApproximateNextMoveTowardsTarget(game.getGhostCurrentNodeIndex(ghostType),
							game.getPacmanCurrentNodeIndex(), game.getGhostLastMoveMade(ghostType), DM.PATH));
				}
			}
		}
		return moves;
	}
	
	public static Pair findNearestGhostToPill(Game game,int pill) {
		Ghosts.Pair g = new Ghosts.Pair(-1,0);
		double min = Double.POSITIVE_INFINITY;
		if(pill!=-1)
		{
		for(GHOST ghostype : GHOST.values()) {
			double distance = game.getDistance(game.getGhostCurrentNodeIndex(ghostype), pill, DM.PATH);
			if(min > distance && distance!=-1) {
				min = distance;
				g.setIndex1(game.getGhostCurrentNodeIndex(ghostype));
			}
			}
		}
		g.setIndex2(min);
		return g;
	}
	
	public static Pair DistMsPacManNearPill(Game game) {
	Ghosts.Pair x=new Ghosts.Pair(-1,0);
		double min = Double.POSITIVE_INFINITY;
		for(int pill : game.getActivePowerPillsIndices()) {
			double distance = game.getDistance(game.getPacmanCurrentNodeIndex(), pill, DM.PATH);
			if( distance < min && distance!=-1)
			{
				x.setIndex1(pill);
				min=distance;
			}
		}
		x.setIndex2(min);
		return x;
	}
	
	public static class Pair{
			
		int index1;
		double index2;
		public int getIndex1() {
			return index1;
		}
		public void setIndex1(int index1) {
			this.index1 = index1;
		}
		public double getIndex2() {
			return index2;
		}
		public void setIndex2(double index2) {
			this.index2 = index2;
		}
		public Pair(int index1, double index2) {
			super();
			this.index1 = index1;
			this.index2 = index2;
		}
		
	}
}

